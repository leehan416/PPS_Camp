n = list(map(int, input()))
n.sort(reverse=True)
for i in n:
    print(i, end='')