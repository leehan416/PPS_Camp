#include <iostream>

using namespace std;

int main() {
    cout << "\\    /\\\n"
         << " )  ( ')\n"
         << "(  /  )\n"
         << " \\(__)|";
    return 0;
}