#include <iostream>

using namespace std;

int main() {
    cout << "|\\_/|" << '\n';
    cout << "|q p|   /}" << '\n';
    cout << "( 0 )\"\"\"\\" << '\n';
    cout << "|\"^\"`    |" << '\n';
    cout << "||_/=\\\\__|" << '\n';
    return 0;
}