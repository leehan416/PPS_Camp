n = int(input())
if 90 <= n:
    print("A")
elif 80 <= n:
    print("B")
elif 70 <= n:
    print("C")
elif 60 <= n:
    print("D")
else:
    print("F")
