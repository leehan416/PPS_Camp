i = int(input())
for index in range(1, i + 1):
    print("*" * index)