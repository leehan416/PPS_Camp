# https://www.acmicpc.net/problem/5988
n = int(input())
for i in range(n):
    temp = int(input())
    if temp %2 == 1:
        print("odd")
    else :
        print("even")